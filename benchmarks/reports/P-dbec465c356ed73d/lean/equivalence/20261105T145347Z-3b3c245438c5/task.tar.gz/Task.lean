import Lean
namespace Task
abbrev Words := List Int
def iz (xs : Words) (i : Nat) : Int := (xs[i]?).getD 0
def finish (xs : Words) : Words := Int.ofNat xs.length :: xs
def factorialRec : Nat → Int | 0 => 1 | n+1 => Int.ofNat (n+1) * factorialRec n
def factorialAcc : Nat → Int → Int
  | 0,a => a
  | n+1,a => factorialAcc n (a*Int.ofNat (n+1))
def inRange (v lo hi : Int) : Bool := lo ≤ v && v ≤ hi
def valid (xs : Words) : Prop := (xs.length == 1 && inRange (iz xs 0) 0 12) = true
def a (xs : Words) : Option Words := some (finish [factorialRec (iz xs 0).toNat])
def b (xs : Words) : Option Words := some (finish [factorialAcc (iz xs 0).toNat 1])
def equivalent : Prop := ∀ x, valid x → ∃ o, a x = some o ∧ b x = some o
def refutationAt (x oa ob : Words) : Prop := valid x ∧ a x = some oa ∧ b x = some ob ∧ oa ≠ ob
end Task
