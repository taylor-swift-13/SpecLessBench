import Task
namespace Obligation
def goal : Prop := Task.equivalent
end Obligation
