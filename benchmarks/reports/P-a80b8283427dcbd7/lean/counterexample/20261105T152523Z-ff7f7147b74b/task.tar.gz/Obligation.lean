import Task
namespace Obligation
def goal : Prop := Task.refutationAt [1] [1,1] [1,0]
end Obligation
